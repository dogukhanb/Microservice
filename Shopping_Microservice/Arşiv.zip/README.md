# Başlangıç Komutu

npm init --y && npm i express cors dotenv && npm i nodemon -D

# DockerFile

- Image oluşturmak için kullanılan bir dosyadır. Her docker file bir dizi komut içerir.
- FROM
- RUN
- COPY
- WORKDIR
- CMD
- EXPOSE
- ENV
