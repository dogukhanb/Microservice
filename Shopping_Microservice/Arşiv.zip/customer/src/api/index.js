module.exports = {
  customer: require("./customer"),
};
