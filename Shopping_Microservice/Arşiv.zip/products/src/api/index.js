module.exports = {
  products: require("./products"),
  appEvents: require("./app-events"),
};
